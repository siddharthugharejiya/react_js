import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "../App.css"

const Login = () => {
  const [login, setLogin] = useState({
    email: "",
    password: ""
  });

  const navigate = useNavigate();

  const change = (e) => {
    setLogin({ ...login, [e.target.name]: e.target.value });
  }

  const sub = (e) => {
    e.preventDefault();
    if (login.email) {
      fetch(`http://localhost:3000/User?email=${login.email}`)
        .then(res => res.json())
        .then((res) => {
          localStorage.setItem("Login", true);
          if (res.length > 0) {
            if (res[0].password === login.password) {
              alert("Login Successful");
              navigate("/");
            } else {
              alert("Password Mismatch");
            }
          } else {
            alert("Register first");
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  return (
    <div className="container-fluid d-flex justify-content-center align-items-center">
    <div className="box mt-5">
      <form className="form" onSubmit={sub}>
        <h2>Login</h2>
        <div className="inputBox">
          <input
            type="email"
            name="email"
            required="required"
            onChange={change}
          />
          <span>Email</span>
          <i></i>
        </div>
        <div className="inputBox">
          <input
            type="password"
            name="password"
            required="required"
            onChange={change}
          />
          <span>Password</span>
          <i></i>
        </div>
        <input type="submit" value="Login" />
      </form>
    </div>
    </div>

  );
}

export default Login;
