import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Dropdown from 'react-bootstrap/Dropdown';
import { Link } from 'react-router-dom';
import "../App.css"
import img from "../image/logo_3_200x.png"

function Navbar1() {
  return (
    <div className="continer-fluid">
   <Navbar expand="lg" className='bg-dark'>
      <Container>
      <Navbar.Brand >
            <img
              src={img}
              width="100%"
              height=""
              className="d-inline-block align-top"
              alt="React Bootstrap logo"
            />
          </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="m-auto">
            <Nav.Link as={Link} to={"/"} className='text-light'>Home</Nav.Link>
            <Nav.Link as={Link} to={"/"} className='text-light'>Fortnight</Nav.Link>
            <Nav.Link as={Link} to={"/"} className='text-light'>Minecraft</Nav.Link>
            <Nav.Link as={Link} to={"/"} className='text-light'>Sports</Nav.Link>
            <Nav.Link as={Link} to={"/Product"} className='text-light'>Product</Nav.Link>
            <Nav.Link as={Link} to={"/Signup"}>Singup</Nav.Link>
         
  
           
          </Nav>
        </Navbar.Collapse>
        <i className="fa-solid fa-magnifying-glass text-light"></i>  
      <Dropdown style={{transition:"2s"}}>
      <Dropdown.Toggle className='bg-dark border-0'>
      <i className="fa-solid fa-user text-light"></i>
      </Dropdown.Toggle>
         
      <Dropdown.Menu>
        <Dropdown.Item href="#/action-1"><Link as={Link} to={"/Login"}>Login</Link></Dropdown.Item>
        <Dropdown.Item href="#/action-2"><Link as={Link} to={"/Signup"}>Singup</Link></Dropdown.Item>
       
      </Dropdown.Menu>
    </Dropdown>
    

      </Container>
    </Navbar>
    </div>
 
  );
}

export default Navbar1;
