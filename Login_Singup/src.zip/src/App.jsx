
import './App.css'
import Navbar1 from './Routes/Navbar_'
import Main_Routes from './Routes/Main_Routes'


function App() {
  
  return (
    <>
     <Navbar1/>
      <Main_Routes/>
    </>
  )
}

export default App
