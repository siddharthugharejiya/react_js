
import './App.css'
import { Firebase_Com } from './Componets/Firebase_Com'

function App() {


  return (
  <>
  <Firebase_Com/>
  </>
  )
}

export default App
